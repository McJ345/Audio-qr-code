
export default function Home() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>One-Time Audio Drop</h1>
      <p><a href="/api/download" style={{ fontSize: "20px" }}>Download Audio</a></p>
    </div>
  );
}
