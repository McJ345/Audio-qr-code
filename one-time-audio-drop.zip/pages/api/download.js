
let used = false;

export default async function handler(req, res) {
  if (used) {
    res.status(403).send("Link expired. This audio can only be downloaded once.");
  } else {
    used = true;
    res.setHeader('Content-Disposition', 'attachment; filename="audio.mp3"');
    res.setHeader('Content-Type', 'audio/mpeg');
    const fs = require("fs");
    const path = require("path");
    const filePath = path.resolve("./public/audio", "AUD-20250411-WA0012.mp3");
    const fileStream = fs.createReadStream(filePath);
    fileStream.pipe(res);
  }
}
