# One-Time Audio Drop
This app allows a single download of an audio file. After the first download, the link is disabled.